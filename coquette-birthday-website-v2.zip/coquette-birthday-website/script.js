let audioContext = null;
let isPlaying = false;
let songTimers = [];
const record = document.getElementById("record");
const statusText = document.getElementById("musicStatus");
const toggle = document.getElementById("musicToggle");
const openGift = document.getElementById("openGift");

// A simple synthesized, piano-like Happy Birthday melody.
// Browsers block sound autoplay until the visitor interacts with the page.
const melody = [
  [62,0.38],[62,0.18],[64,0.55],[62,0.55],[67,0.55],[66,0.9],
  [62,0.38],[62,0.18],[64,0.55],[62,0.55],[69,0.55],[67,0.9],
  [62,0.38],[62,0.18],[74,0.55],[71,0.55],[67,0.55],[66,0.55],[64,0.9],
  [72,0.38],[72,0.18],[71,0.55],[67,0.55],[69,0.55],[67,1.0]
];
function playNote(midi, duration, startAt) {
  const freq = 440 * Math.pow(2, (midi - 69) / 12);
  const osc = audioContext.createOscillator();
  const gain = audioContext.createGain();
  const overtone = audioContext.createOscillator();
  const overtoneGain = audioContext.createGain();
  osc.type = "triangle";
  overtone.type = "sine";
  osc.frequency.value = freq;
  overtone.frequency.value = freq * 2;
  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(0.16, startAt + 0.018);
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration * 0.92);
  overtoneGain.gain.setValueAtTime(0.0001, startAt);
  overtoneGain.gain.exponentialRampToValueAtTime(0.025, startAt + 0.02);
  overtoneGain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration * 0.7);
  osc.connect(gain); gain.connect(audioContext.destination);
  overtone.connect(overtoneGain); overtoneGain.connect(audioContext.destination);
  osc.start(startAt); osc.stop(startAt + duration);
  overtone.start(startAt); overtone.stop(startAt + duration);
}
function startSong() {
  if (isPlaying) return;
  audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
  audioContext.resume();
  isPlaying = true;
  record.classList.add("playing");
  toggle.textContent = "Ⅱ";
  statusText.textContent = "Playing a little birthday tune…";
  let t = audioContext.currentTime + 0.08;
  melody.forEach(([note, length]) => {
    playNote(note, length * 0.92, t);
    t += length * 0.48;
  });
  const total = melody.reduce((sum, item) => sum + item[1] * 0.48, 0) * 1000;
  songTimers.push(setTimeout(() => {
    isPlaying = false;
    record.classList.remove("playing");
    toggle.textContent = "↻";
    statusText.textContent = "Your birthday tune has finished. Play it again?";
  }, total + 150));
}
function stopSong() {
  if (audioContext) audioContext.suspend();
  isPlaying = false;
  record.classList.remove("playing");
  toggle.textContent = "▶";
  statusText.textContent = "The record is paused.";
  songTimers.forEach(clearTimeout);
  songTimers = [];
}
function toggleSong() { if (isPlaying) stopSong(); else startSong(); }
openGift.addEventListener("click", () => {
  startSong();
  document.querySelector(".music-strip").scrollIntoView({behavior:"smooth",block:"center"});
  openGift.textContent = "Enjoy your little surprise ♡";
});
toggle.addEventListener("click", toggleSong);

// Keep the photo placeholder visible until the user adds assets/photos/us.jpg.
const usPhoto = document.getElementById("usPhoto");
const photoHint = document.getElementById("photoHint");
if (usPhoto && photoHint) {
  usPhoto.addEventListener("load", () => { photoHint.style.display = "none"; });
  usPhoto.addEventListener("error", () => { usPhoto.style.display = "none"; });
}
