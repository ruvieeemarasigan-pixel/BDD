COQUETTE BIRTHDAY WEBSITE

FILES
- index.html: homepage
- letter.html: your editable birthday letter
- style.css: colors, layout, coquette styling
- script.js: vinyl animation and birthday tune
- assets/photos/: put your own photos here

ADD YOUR PHOTOS
Put 4 images in assets/photos and name them:
us.jpg  (this appears in the little framed photo beside the vinyl)
photo-1.jpg
photo-2.jpg
photo-3.jpg
You can use JPG images. If your images have different names, edit the image src names in index.html.

ADD YOUR LETTER
Open letter.html and replace:
[HER NAME]
[WRITE YOUR LETTER HERE...]
[YOUR NAME]
You can add or remove paragraphs.

MUSIC
Click "Open your little surprise" to start the built-in piano-like Happy Birthday tune and spin the vinyl.
Browsers do not allow websites to start sound automatically before a visitor clicks or taps. The first click is needed to enable sound.
If you want a different piano recording, replace the built-in tune in script.js with an audio player and your own audio file.

PREVIEW
Open index.html in Chrome or Edge.

PUBLISH ON GITHUB
1. Create a new PUBLIC repository.
2. Upload the contents of this folder (not the ZIP itself).
3. Go to Settings > Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Select main and /(root), then Save.
6. Wait for GitHub Pages to publish the site.
